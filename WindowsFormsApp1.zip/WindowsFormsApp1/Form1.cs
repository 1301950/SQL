﻿using GAC.eCRM3.SharedCRMLib.BusinessLogics;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GAC.eCRM3.CRMLib;
using Microsoft.Crm.Services.Utility;
using Microsoft.Xrm.Sdk;
using GAC.eCRM3.SharedCRMLib;
using Microsoft.Xrm.Sdk.Query;
using System.Xml;
using System.IO;
using GAC.eCRM3.SharedCRMLib;
using GAC.eCRM3.SharedCRMLib.BusinessLogics;
using Microsoft.Crm.Sdk.Messages;

namespace WindowsFormsApp1
{
	public partial class Form1 : Form
	{
		public CrmSvcUtil.InteractiveLogin.CRMInteractiveLogin wnd;
		public IOrganizationService OrgService;
		public Form1()
		{
			InitializeComponent();
			wnd = new CrmSvcUtil.InteractiveLogin.CRMInteractiveLogin();
			//wnd.HostProfileName = "uat";
			wnd.HostProfileName = "dev1";
			wnd.ConnectionToCrmCompleted += Wnd_ConnectionToCrmCompleted;
			wnd.ShowDialog();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			
		}


		private void AssignRolesToTeam(Guid? teamid, Guid? roleid, IOrganizationService svc)
		{
			var ctx = new XrmServiceContext(svc);
			
		}

		private void ExecuteWorkflowOnFetch(IOrganizationService svc)
		{
			var fx = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'><entity name='ecrm3_participant'><attribute name='ecrm3_participantid' /><filter type='and'><condition attribute='ecrm3_activity' operator='eq' value='{id}' /></filter></entity></fetch>";
			var id = new Guid("BBBA7087-1EAC-EA11-A812-000D3AF46865");
			var wf = new EntityReference("", new Guid("17691E6F-89AB-EA11-A812-000D3AF413DF"));
			ActivityBusinessLogics.DeleteActivityTree(id, svc);


		}
		public static Microsoft.Xrm.Sdk.Query.QueryExpression qtoqe(IQueryable q)

		{

			var provider = q.Provider;

			var method = q.Provider.GetType().GetMethod("Translate");

			var qe = (Microsoft.Xrm.Sdk.Query.QueryExpression)method.Invoke(provider, new object[] { q.Expression });

			return qe;

		}
		public static string qtofx(IQueryable q, IOrganizationService svc)

		{

			var qe = qtoqe(q);

			var req = new Microsoft.Crm.Sdk.Messages.QueryExpressionToFetchXmlRequest();

			req.Query = qe;

			var resp = (Microsoft.Crm.Sdk.Messages.QueryExpressionToFetchXmlResponse)svc.Execute(req);

			return resp.FetchXml;

		}


		private void TestMergeReparent(IOrganizationService svc)
		{
			var org1 = new Guid("8c7b5909-32bc-ea11-a812-000d3af413df");
			var org2 = new Guid("eabe67dd-9fba-ea11-a812-000d3af46865");
			var ctx = new GAC.eCRM3.CRMLib.XrmServiceContext(svc);
			var org = ctx.AccountSet.FirstOrDefault();

			OrganizationBusinessLogics.ReParent(new EntityReference(Account.EntityLogicalName, org1), new EntityReference(Account.EntityLogicalName, org2), svc);
		}

		

		private void Wnd_ConnectionToCrmCompleted(object sender, EventArgs ea)
		{
			var con = (sender as CrmSvcUtil.InteractiveLogin.CRMInteractiveLogin).CrmConnectionMgr.CrmSvc;
			var svc = (con as Microsoft.Xrm.Sdk.IOrganizationService);
			var ctx = new GAC.eCRM3.CRMLib.XrmServiceContext(svc);
			this.OrgService = svc;

			var cfgg = ctx.ecrm3_systemconfigurationSet.FirstOrDefault();
			SecurityCommon.AssignRoleToTeamByRoleNames(new Guid("334b1941-3af6-ec11-82e5-002248ae4a83"), cfgg.ecrm3_NetworkTeamSecurityRole, svc);

			return;
			var xm = "<xml><relationship name='ecrm3_TCSInitiative_ecrm3_Activity_ecrm3_'><numberfield>ecrm3_nbroftcsactivities</numberfield><fx><![CDATA[<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' aggregate='true'><entity name='ecrm3_activity'><attribute name='ecrm3_activityid' alias='count' aggregate='countcolumn'/><filter type='and'><condition attribute='statuscode' operator='ne' value='994960001'/></filter><link-entity name='ecrm3_tcsinitiative_ecrm3_activity' from='ecrm3_activityid' to='ecrm3_activityid' visible='false' intersect='true'><link-entity name='ecrm3_tcsinitiative' from='ecrm3_tcsinitiativeid' to='ecrm3_tcsinitiativeid' alias='aa'><filter type='and'><condition attribute='ecrm3_tcsinitiativeid' operator='eq' value='{id}'/></filter></link-entity></link-entity></entity></fetch>]]></fx></relationship></xml>";

			var param = "&lt;parameters parentfieldname='ecrm3_parentinitiative' numberfieldname='ecrm3_nbroftcsinitiatives' /&gt;";
			param = param.Replace("&lt;", "<").Replace("&gt;", ">");
			var doc = new XmlDocument();
			doc.LoadXml(xm);

			var rels = doc.FirstChild.ChildNodes;
			var rel = rels.Cast<XmlNode>().Where(e => e.Attributes["name"].Value == "ecrm3_TCSInitiative_ecrm3_Activity_ecrm3_").FirstOrDefault();

			

			var q_r = from ri in ctx.ecrm3_referencevalueSet
					  join ri_p in ctx.ecrm3_referencevalueSet on ri.ecrm3_ParentReferenceItemId.Id equals ri_p.ecrm3_referencevalueId
					  join rh in ctx.ecrm3_referenceheaderSet on ri.ecrm3_HeaderId.Id equals rh.ecrm3_referenceheaderId
					  where rh.ecrm3_code == "outcome"
					  select new { ri.ecrm3_code, parentcode = ri_p.ecrm3_code };

			var r_r = q_r.ToList();
			var resff = svc.RetrieveMultiple(new FetchExpression("<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'><entity name='ecrm3_countryadministrativedivision'><attribute name='ecrm3_name'/><link-entity name='ecrm3_countryadministrativedivision' from='ecrm3_parent' to='ecrm3_countryadministrativedivisionid' link-type='inner' alias='ao'><attribute name='ecrm3_name'/><link-entity name='ecrm3_countryadministrativedivision' from='ecrm3_parent' to='ecrm3_countryadministrativedivisionid' link-type='inner' alias='ap'><attribute name='ecrm3_name'/><filter type='and'><condition attribute='ecrm3_countryadministrativedivisionid' operator='eq' value='{1E75091C-CE9A-EA11-A812-000D3AF46865}'/></filter></link-entity></link-entity></entity></fetch>"));

			ParticipantBusinessLogics.CopyColleaguesFrom(new EntityReference(ecrm3_Activity.EntityLogicalName, new Guid("7C4142C9-79BD-4083-A712-D031C456CD33")), new EntityReference(ecrm3_outcome.EntityLogicalName, new Guid("1D78F084-8EFC-48C6-A8D4-C7D5E31F3D45")), svc);

			//ReferenceListBusinessLogics.OptionsetToReferenceValue("ecrm3_subsector", "service", svc);
			//var lsss = ctx.ecrm3_TCSInitiative_ecrm3_ActivitySet.Where(e => e.ecrm3_tcsinitiativeid == new Guid("2fcaa80d-64ff-ea11-a813-000d3af42496")).ToList();
			var fffs = ctx.ecrm3_TCSInitiative_ecrm3_outcomeSet.Where(e => e.ecrm3_tcsinitiativeid == new Guid("2fcaa80d-64ff-ea11-a813-000d3af42496")).ToList();

			var fx = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' aggregate='true'><entity name='ecrm3_outcome'><attribute name='ecrm3_outcomeid' alias='count' aggregate='countcolumn'/><link-entity name='ecrm3_tcsinitiative_ecrm3_outcome' from='ecrm3_outcomeid' to='ecrm3_outcomeid' visible='false' intersect='true'><link-entity name='ecrm3_tcsinitiative' from='ecrm3_tcsinitiativeid' to='ecrm3_tcsinitiativeid' alias='ac'><filter type='and'><condition attribute='ecrm3_tcsinitiativeid' operator='eq' value='{id}' /></filter></link-entity></link-entity></entity></fetch>";

			GAC.eCRM3.Common.Utils.GetCountFromFetch(svc, fx, new Guid("2fcaa80d-64ff-ea11-a813-000d3af42496"), null, null);

			var oldparent = new EntityReference("", new Guid("2FCAA80D-64FF-EA11-A813-000D3AF42496"));
			GenericBusinessLogics.UpdateNumberOfRelatedEntitiesByFetchxml(oldparent, fx, ecrm3_TCSInitiative.ecrm3_nbroftcsactivitiesAttribute, svc);

			ActivityBusinessLogics.LinkInitiativesToChildActivities(new Guid("37271A47-1FCA-45B2-A4C0-B81AFA1FC343"), new Guid("24D1384D-56EE-4E03-A5AC-04F481415C9C"), svc);

			var accc = ctx.ecrm3_ActivitySet.FirstOrDefault();
			OutcomeBusinessLogics.RollupOutcomeFromActivities(new Guid("336F30BB-4495-45C3-9E4B-1D0190DC92D9"), svc);
			
			//lst.Where(e => e.ecrm3_typeoption.Value == 1).Count();
			ActivityBusinessLogics.ActivityBPF_MovePrevStage(svc, new Guid("EC70BA99-85ED-4799-9974-164592B61B5A"));
			return;

			
			

			ActivityBusinessLogics.AddMarketToOrganizationMarkets(svc, new EntityReference(ecrm3_CountryAdministrativeDivision.EntityLogicalName, new Guid("e99bf95b-149a-ea11-a813-000d3af43d75")), new EntityReference(Account.EntityLogicalName, new Guid("5116ef4f-e6b1-4342-a5aa-bb43edd1c4b6")));

			var er_country = SystemUserBusinessLogics.GetOfficeCountryFromUser(new Guid("728E031A-0F96-EA11-A812-000D3AF4316A"), ctx);

			GenericBusinessLogics.DeleteTree(new Guid("3296DF32-A1DB-EA11-A813-000D3AF42496"), ecrm3_systemconfiguration.ecrm3_activitydeletetreeAttribute, svc);

			//var res = GAC.eCRM3.Common.Utils.GetMultOptionsetValueNames("ecrm3_businessrole", "ecrm3_securityroles", new Guid("6F0B8DF7-46AB-EA11-A812-000D3AF413DF"), svc);
			//SecurityCommon.AssignRoleToTeamByRoleNames(new Guid("1681A88B-7895-EA11-A812-000D3AF413DF"), res, svc);
			

			var rd = ctx.BusinessUnitSet.Where(bu => bu.UTCOffset != null).FirstOrDefault();
			var offset = rd.UTCOffset;

			var q = from r in ctx.ecrm3_BusinessRoleSet
					join e in ctx.TeamSet on r.ecrm3_BusinessRoleId equals e.ecrm3_Basebusinessrole.Id
					where r.ecrm3_BusinessRoleId == Guid.Empty
					select new { r.ecrm3_SecurityRoles };

			
			
			SecurityCommon.AssignRoleToTeamByRoleNames(new Guid("a3360587-facc-ea11-a818-000d3af4316a"), "ECRM3 User Readonly", svc);
			OrganizationBusinessLogics.UpdatePrimaryOrgInActivities(new Guid("3621D747-E795-EA11-A812-000D3AF413DF"), new EntityReference(Account.EntityLogicalName, new Guid("43884E1B-2795-EA11-A812-000D3AF413DF")), svc);
			ContactBusinessLogics.UpdateContactLatestActivityDate(new Guid("07022CAF-1EB6-EA11-A812-000D3AF46865"), svc);
			var efx = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'><entity name='ecrm3_organizationcontact'><attribute name='ecrm3_organizationcontactid'/><filter type='and'><filter type='or'><condition attribute='ecrm3_tobedeleted' operator='null'/><condition attribute='ecrm3_tobedeleted' operator='eq' value='0'/></filter></filter><link-entity name='ecrm3_activity' from='ecrm3_organizationcontact' to='ecrm3_organizationcontactid' link-type='inner' alias='ac'><filter type='and'><condition attribute='modifiedon' operator='olderthan-x-months' value='{Tag Contact with activities older than (months)(System Configuration)}'/></filter></link-entity></entity></fetch>|<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'><entity name='ecrm3_organizationcontact'><attribute name='ecrm3_organizationcontactid'/><filter type='and'><filter type='or'><condition attribute='ecrm3_tobedeleted' operator='null'/><condition attribute='ecrm3_tobedeleted' operator='eq' value='0'/></filter></filter><link-entity name='ecrm3_activity' from='ecrm3_organizationcontact' to='ecrm3_organizationcontactid' link-type='inner' alias='ac'><filter type='and'><condition attribute='modifiedon' operator='last-x-months' value='{Tag Contact with activities older than (months)(System Configuration)}'/></filter></link-entity></entity></fetch>";
			efx = efx.Replace("{Tag Contact with activities older than (months)(System Configuration)}", "1");
			ContactBusinessLogics.DeactivateContactByFetch(efx, svc);
			var saved = ctx.CreateQuery("SavedQuery").Where(e => e.GetAttributeValue<Guid>("savedqueryid") == new Guid("381a623b-b3a9-4c19-8484-c89c29ac7727")).FirstOrDefault();
			TestMergeReparent(svc);

			//AddressBusinessLogics.GetPhoneMaskByOrgCountry(new Guid("289E0F2C-02B7-EA11-A812-000D3AF413DF"), ctx);
			SecurityBusinessLogics.RemoveAllRoles(new Guid("519F1721-9794-EA11-A812-000D3AF43355"), "ecrm3", svc);

			ExecuteWorkflowOnFetch(svc);


			GetSelectedValues(new EntityReference("ecrm3_businessrole", new Guid("1ea9efe4-46ab-ea11-a812-000d3af413df")), "ecrm3_securityroles", null, svc);

			SecurityCommon.AssignRoleToUserByRoleName(new Guid("1ea9efe4-46ab-ea11-a812-000d3af413df"), "ECRM3 User General", svc);

			ctx.CreateQuery("SavedQueries").Where(e => e.Id == new Guid("7ef50d99-3fd8-4adf-8025-2e7a8ece678f")).FirstOrDefault();

			var acc = new Account() { Name = "ottawa co" };
			var id = svc.Create(new Account() { Name = "ottawa co" });
			acc.Id = id;
			svc.Create(new ecrm3_organizationmarket() { ecrm3_Organization = acc.ToEntityReference() });
			svc.Create(new ecrm3_OrganizationProduct() { ecrm3_Organization = acc.ToEntityReference() });

			

			var lst_bus = ctx.BusinessUnitSet.Where(e => e.ecrm3_MarketofResponsibilityId == null).ToList();
			var d = ctx.ecrm3_systemconfigurationSet.Select(cfg => new { cfg.ecrm3_OwnerTeamRole, cfg.ecrm3_OwnerTeamAdministrator }).FirstOrDefault();
			var rolename = d.ecrm3_OwnerTeamRole;
			var teamadmin = d.ecrm3_OwnerTeamAdministrator;

			foreach (var bu in lst_bus)
			{
				var team = new Team()
				{
					Name = bu.Name + " Team",
					BusinessUnitId = bu.ToEntityReference(),
					TeamType = team_type.Owner,
					AdministratorId = teamadmin
				};
				Guid teamid = Guid.Empty;
				if (bu.ecrm3_MarketofResponsibilityId != null)
				{
					team.TeamId = bu.ecrm3_MarketofResponsibilityId.Id;
					teamid = team.TeamId.Value;
					svc.Update(team);
				}
				else
				{
					var tid = ctx.TeamSet.Where(e => e.Name == team.Name).Select(e => e.TeamId).FirstOrDefault();
					if (tid != null)
					{
						teamid = tid.Value;
						team.TeamId = teamid;
					}
					else
					{
						teamid = svc.Create(team);
						SecurityCommon.AssociateRoleToTeam(rolename, bu.BusinessUnitId.Value, teamid, svc);
					}


				}

			}

			foreach (var bu in lst_bus)
			{
				var team = new Team()
				{
					Name = bu.Name + " Team",
					BusinessUnitId = bu.ToEntityReference(),
					TeamType = team_type.Owner,
					AdministratorId = teamadmin
				};
				Guid teamid = Guid.Empty;
				if (bu.ecrm3_MarketofResponsibilityId != null)
				{
					team.TeamId = bu.ecrm3_MarketofResponsibilityId.Id;
					teamid = team.TeamId.Value;
					svc.Update(team);
				}
				else
				{
					var tid = ctx.TeamSet.Where(e => e.Name == team.Name).Select(e => e.TeamId).FirstOrDefault();
					if (tid != null)
					{
						teamid = tid.Value;
						team.TeamId = teamid;
					}
					else
					{
						teamid = svc.Create(team);
						SecurityCommon.AssociateRoleToTeam(rolename, bu.BusinessUnitId.Value, teamid, svc);
					}


					svc.Update(new BusinessUnit()
					{
						BusinessUnitId = bu.BusinessUnitId,
						ecrm3_MarketofResponsibilityId = team.ToEntityReference()
					}); ;
				}

			}

			

			//ServiceBusinessLogics.MoveBPFStageOnOutcallStatus(new Guid("08ECE1DE-AFD4-E911-A812-000D3AF464F8"), GAC.eCRM3.CRMLib.processstage_category.Done, svc);

			throw new NotImplementedException();
		}
		public static string GetSelectedValues(EntityReference sourceEntityReference, string attributeName, ITracingService tracingService, IOrganizationService organizationService)
		{
			if (sourceEntityReference == null || attributeName == null)
			{
				tracingService?.Trace("Null parameters have been passed, so string will be empty");
				return string.Empty;
			}

			Entity sourceEntity = organizationService.Retrieve(sourceEntityReference.LogicalName, sourceEntityReference.Id, new ColumnSet(attributeName));

			if (!sourceEntity.Contains(attributeName))
			{
				tracingService?.Trace("Attribues {0} was not found", attributeName);
				return string.Empty;
			}

			OptionSetValueCollection optionSetValues = sourceEntity[attributeName] as OptionSetValueCollection;
			if (optionSetValues == null)
				return string.Empty;

			int numberOptions = optionSetValues.Count;

			if (numberOptions == 0)
			{
				tracingService?.Trace("No selected options");
				return string.Empty;
			}

			tracingService?.Trace("Number of selected options: ", numberOptions);

			StringBuilder stringBuilder = new StringBuilder();
			OptionSetValue value = null;
			for (int i = 0; i < numberOptions; i++)
			{
				value = optionSetValues[i];
				stringBuilder.Append(value.Value);
				if ((i + 1) < numberOptions)
					stringBuilder.Append(",");
			}

			string values = stringBuilder.ToString();
			tracingService?.Trace("Values have been retrieved correctly. Values: ", values);

			return values;
		}
		private void button2_Click(object sender, EventArgs e)
		{
			var dialog = new OpenFileDialog();
			var res = dialog.ShowDialog();
			if (res != DialogResult.Cancel)
			{
				var fn = dialog.FileName;
				var doc = new System.Xml.XmlDocument();
				doc.Load(fn);
				var desc = doc.ChildNodes[1].ChildNodes[1].ChildNodes[1].InnerXml;
				var docnodes = doc.ChildNodes[1].ChildNodes[1].ChildNodes;

				var sw = new StreamWriter("Workflow Assembly Documentation.html");
				sw.WriteLine(@"<html>
<style>
body, html {
    font-family: Arial;
    font-size: 13;
    text-rendering: optimizeLegibility;
    -webkit-font-smoothing: antialiased;
}
</style>
<body>");
				foreach (System.Xml.XmlNode n in docnodes)
				{
					var xml = n.InnerXml;
					if (xml.Contains("<ecrm3>"))
					{
						var classname = n.Attributes["name"].Value;
						classname = classname.Replace("M:", "").Replace("T:", "");
						var idx = classname.IndexOf(".Execute(");
						if (idx > 0) classname = classname.Substring(0, idx);
						var xd = new XmlDocument();
						xd.LoadXml(n.OuterXml);
						var helptext = xd.FirstChild.FirstChild.FirstChild.InnerXml;

						sw.WriteLine($"<h2>{ classname.Substring(classname.LastIndexOf(".") + 1) }</h2>");
						sw.WriteLine($"<b>Fullname: </b>{ classname }<br>");
						sw.WriteLine($"{ helptext }<br>");
						sw.WriteLine("<br>");
					}
				}
				sw.WriteLine("</body></html>");
				sw.Close();
			}
		}

		private void button4_Click(object sender, EventArgs e)
		{
			var dialog = new OpenFileDialog();
			var res = dialog.ShowDialog();
			if (res != DialogResult.Cancel)
			{
				var fn = dialog.FileName;
				var doc = new System.Xml.XmlDocument();
				doc.Load(fn);
				var desc = doc.ChildNodes[1].ChildNodes[1].ChildNodes[1].InnerXml;
				var docnodes = doc.ChildNodes[1].ChildNodes[1].ChildNodes;

				var sw = new StreamWriter("Plugin Documentation.html");
				sw.WriteLine(@"<html>
<style>
table{
border-collapse: collapse
}
td{
padding: 15px;
text-align:left;
border: solid 2px lightgrey;
}
th
{
padding: 15px;
text-align:left;
border: solid 2px lightgrey;

}
body, html {
    font-family: Arial;
    font-size: 13;
    text-rendering: optimizeLegibility;
    -webkit-font-smoothing: antialiased;
}
</style>
<body>");
				foreach (System.Xml.XmlNode n in docnodes)
				{
					var xml = n.InnerXml;
					if (xml.Contains("<ecrm3>"))
					{
						var classname = n.Attributes["name"].Value;
						classname = classname.Replace("M:", "").Replace("T:", "");
						var idx = classname.IndexOf(".Execute(");
						if (idx > 0) classname = classname.Substring(0, idx);

						var arr_names = classname.Split('.');



						var xd = new XmlDocument();
						xd.LoadXml(n.OuterXml);
						var helptext = xd.FirstChild.FirstChild.FirstChild.InnerXml;
						idx = helptext.IndexOf("<trigger");
						sw.WriteLine($"<h2>{ arr_names[arr_names.Length - 2] + "." + arr_names[arr_names.Length - 1] }</h2>");
						sw.WriteLine($"<h3><b>Fullname: </b>{ classname }</h3>");

						sw.WriteLine($"{  helptext.Substring(0, idx) }");
						sw.WriteLine("<br>");


						var pluginxml = helptext.Substring(idx, helptext.Length - idx);
						var docplug = new XmlDocument();
						docplug.LoadXml(pluginxml);
						var triggers = docplug.FirstChild.ChildNodes;
						sw.WriteLine("<table style='font-size: 13'><tr><th>Triggering Fields</th><th>Descriptions</th></tr>");
						foreach (XmlNode tn in triggers)
						{
							sw.WriteLine("<tr>");

							// fields
							var fieldNodes = tn.ChildNodes[0];
							sw.WriteLine($"<td>");
							var lst = new List<string>();
							foreach (XmlNode fnode in fieldNodes)
							{
								lst.Add(fnode.InnerText);
							}
							sw.WriteLine(string.Join(",", lst));
							sw.WriteLine($"</td>");
							sw.WriteLine($"<td>");
							var descnode = tn.ChildNodes[1];
							sw.WriteLine(descnode.InnerXml);
							sw.WriteLine($"</td>");
							sw.WriteLine("</tr>");
						}
						sw.WriteLine("</table>");
					}
				}
				sw.WriteLine("</body></html>");
				sw.Close();
			}
		}

		private void button1_Click_1(object sender, EventArgs e)
		{
			GetDependency(OrgService);
		}

		public static void GetDependency(IOrganizationService svc)
		{
			var ctx = new XrmServiceContext(svc);
			//var lst = ctx.WebResourceSet.Where(e => e.Name.Contains("ecrm3_orgcontact")).ToList();
			var lst = ctx.WebResourceSet.Where(e => e.Name.Contains("ecrm3_")).ToList();
			var sw = new StreamWriter("javascriptdoc.html");
			var sb = new StringBuilder();
			sw.WriteLine(@"<html>
<style>
table{
border-collapse: collapse
}
td{
padding: 15px;
text-align:left;
border: solid 2px lightgrey;
}
th
{
padding: 15px;
text-align:left;
border: solid 2px lightgrey;

}
body, html {
    font-family: Arial;
    font-size: 13;
    text-rendering: optimizeLegibility;
    -webkit-font-smoothing: antialiased;
line-height: 1.5;
}
</style>
<body>");
			sb.AppendLine("<b>Webresource</b>");
			foreach (var wr in lst)
			{
				var displayname = wr.DisplayName;

				sb.AppendLine($"<h2>{ displayname }</h2>");

				var codes = Encoding.UTF8.GetString(Convert.FromBase64String(wr.Content));

				var name = wr.Name;
				sb.AppendLine($"<b>Fullname: </b>{ name }<br>");

				sb = ProcessJSDoc(codes, wr.Id, sb, svc);

				

				//sb.AppendLine("<hr>");
			}
			sw.WriteLine(sb.ToString());
			sw.WriteLine("</body></html>");
			sw.Close();
		}

		public static StringBuilder GetDependencies(IOrganizationService svc, StringBuilder sb, Guid wrid)
		{
			var ctx = new XrmServiceContext(svc);
			var req = new RetrieveDependentComponentsRequest()
			{
				ComponentType = (int)componenttype.WebResource,
				ObjectId = wrid,

			};
			var resp = (RetrieveDependentComponentsResponse)svc.Execute(req);
			var dep = resp.EntityCollection.Entities.ToList().Select(e => (Dependency)e).ToList();

			sb.AppendLine("<h3>Dependencies</h3>");

			if (dep.Count > 0)
			{
				sb.AppendLine("<table style='font-size: 13'><tr><th>Dependency Type</th><th>Entity Name</th><th>Form Name</th></tr>");
				foreach (var d in dep)
				{
					sb.AppendLine("<tr>");
					var depCompType = (componenttype)d.DependentComponentType.Value;
					if (depCompType == componenttype.RibbonCustomization)
					{
						sb.AppendLine("<td>Ribbon Customization</td>");
						var entity = ctx.RibbonCustomizationSet.Where(e => e.Id == d.DependentComponentObjectId).Select(e => e.Entity).FirstOrDefault();
						sb.AppendLine("<td>" + entity + "</td><td></td>");
					}
					else if (depCompType == componenttype.CustomControlDefaultConfig)
					{
						sb.AppendLine("<td>Custom Control</td>");
						var controlname = ctx.CustomControlDefaultConfigSet.Where(e => e.Id == d.DependentComponentObjectId).Select(e => e.LogicalName).FirstOrDefault();
						sb.AppendLine("<td>" + controlname + "</td><td></td>");
					}
					else if (depCompType == componenttype.WebResource)
					{
						sb.AppendLine("<td>Web resource</td>");
						var controlname = ctx.WebResourceSet.Where(e => e.Id == d.DependentComponentObjectId).Select(e => e.DisplayName).FirstOrDefault();
						sb.AppendLine("<td>" + controlname + "</td><td></td>");
					}
					else
					{
						sb.AppendLine("<td>Form</td>");
						var form = ctx.SystemFormSet.Where(e => e.Id == d.DependentComponentObjectId).FirstOrDefault();
						var formname = form.Name;
						var entity = form.ObjectTypeCode;
						sb.AppendLine("<td>" + entity + "</td><td>" + formname + "</td>");
					}
					sb.AppendLine("</tr>");
				}
				sb.AppendLine("</table>");
			}
			return sb;
		}

		public static StringBuilder ProcessJSDoc(string doc, Guid wrid, StringBuilder sb, IOrganizationService svc)
		{

			var lines = doc.Split('\n');
			lines = lines.Where(l => l.IndexOf("///") >= 0).ToArray();

			if (lines.Length > 0)
			{

				var comments = "<xml>" + string.Join("", lines.Where(l => l.IndexOf("///") >= 0).Select(e => e.Replace("///", "")).ToList()) + "</xml>";
				var xdoc = new System.Xml.XmlDocument();
				xdoc.LoadXml(comments);
				var xn_summary = xdoc.SelectSingleNode("//summary");
				if (xn_summary == null) return sb;
				var summary = xdoc.SelectSingleNode("//summary").InnerText;

				sb.AppendLine(summary + "<br>");
				GetDependencies(svc, sb, wrid);
				sb.AppendLine("<br>");

				sb.AppendLine("<h3>Functions</h3>");

				var functions = xdoc.SelectNodes("//function");

				sb.AppendLine("<table style='font-size: 13'><tr><th>Function name</th><th>Descriptions</th></tr>");
				foreach (System.Xml.XmlNode xn in functions)
				{
					sb.AppendLine("<tr>");
					var newdoc = new System.Xml.XmlDocument();
					newdoc.LoadXml("<xml>" + xn.InnerXml + "</xml>");

					var functionName = newdoc.SelectSingleNode("//name").InnerText;
					var functionDescription = newdoc.SelectSingleNode("//description").InnerText;
					sb.AppendLine("<td>" + functionName + "</td>");
					sb.AppendLine("<td>" + functionDescription + "</td>");

					sb.AppendLine("</tr>");
				}
				sb.AppendLine("</table>");

			}
			return sb;
		}

	}
}
